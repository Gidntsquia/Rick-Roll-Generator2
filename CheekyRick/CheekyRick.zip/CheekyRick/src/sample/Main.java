package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import javafx.scene.web.WebView;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;


public class Main extends Application {
    File desc = new File("description.txt");
    File title = new File("title.txt");



    @Override
    public void start(Stage primaryStage) throws Exception{
        BorderPane borderPane = new BorderPane();
        Button playbackButton = new Button("Play Video");
        CheckBox reachNewHeights = new CheckBox();
        TextField nameToChange = new TextField("New Title Here");
        TextField description = new TextField("New Description Here");
        Label toNewHeights = new Label("Reach New Heights");

        WebView myview = new WebView();
        //final WebEngine rickrollmachine = myview.getEngine();
        //rickrollmachine.load("google.com");
        VBox vbox = new VBox();
        HBox hbox = new HBox();
        //VBox rickbox = new VBox(myview);
        hbox.getChildren().addAll(reachNewHeights, toNewHeights);
        vbox.getChildren().addAll(nameToChange,
                description,
                hbox,
                playbackButton);
        if(desc.createNewFile()){
            System.out.println("Description Created");
        } else System.out.println("Description already exists");
        if(title.createNewFile()){
            System.out.println("Title Created");
        } else System.out.println("Title already exists");



        borderPane.setLeft(vbox);
        //borderPane.setRight(rickbox);
        primaryStage.setTitle("Rick-Roll-inator");
        primaryStage.setScene(new Scene(borderPane, 1000, 600));
        primaryStage.show();

        playbackButton.setOnAction(e -> {
            if(reachNewHeights.isSelected()){
                //rickrollmachine.load("https://www.youtube.com/watch?v=B5XZBXaco1Y");
            }
            else{
                //rickrollmachine.load("https://www.youtube.com/watch?v=oHg5SJYRHA0");
            }
            try {
                Writer w = new FileWriter("title.txt");
                w.write(nameToChange.getText());
            } catch (Exception g) {
                System.out.println("something broke.");
            }
            try {
                Writer w = new FileWriter("description.txt");
                w.write(description.getText());
            } catch (Exception g) {
                System.out.println("something broke.");
            }



        });
    }


    public static void main(String[] args) {
        launch(args);
    }
}